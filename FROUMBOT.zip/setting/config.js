const fs = require('fs')

global.owner = "6285785960079" //owner number
global.namaowner = "KINGFROUM" //owner name
global.footer = "FROUM BOT" //footer section
global.status = true //"self/public" section of the bot

global.lol = "";
global.mess = {
    owner: "\`[ !! ]\`\nFitur Khusus Developer Kocak🤭",
    group: "\`[ FROUM 𝐕𝐈𝐏!! ]\`\nFitur Khusus Di Dalam Group",
    private: "\`[ FROUM 𝐕𝐈𝐏!! ]\`\nFitur Khusus Private Chat",
    murbug: "\`[ FROUM 𝐕𝐈𝐏!! ]\`\nFitur Khusus Pengguna Murbug",
    admin: "\`[ FROUM 𝐕𝐈𝐏!! ]\`\nFitur Khusus Admin Group",
    botadmin: "\`[ FROUM 𝐕𝐈𝐏!! ]\`\nBot Harus Admin Terlebih Dahulu"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
